
print("helloworld")
# 5 data types in python : integers , string  ()' " '''), float , boolean (True/False), none(no value stored in that variable)
# Keywords are : and , as ,assert , break , class , continue , def , del , if , elif , else , except , finally , False , True , for , global , import , in , is , lambda , nonlocal , None , not , or , pass , raise, return , try , with , while , yield
# input suncion always enters a string
str1 = "7"
str2 = "4"
final_str = str1 + str2
print(final_str)
#The capitalize() function in Python is used to capitalize the first letter of a string. It turns the rest of all letters to lowercase. 
#for palindrome , copy list ,reverse and compare
#lists and dixtonaries are mutable
#tuples and sets are immutable , cos theyre converted to hashvalues
#sets are unordered , hence o\we use pop to get single values out of it