print(" Lets write a poem!")
print("")
print("|____|")
